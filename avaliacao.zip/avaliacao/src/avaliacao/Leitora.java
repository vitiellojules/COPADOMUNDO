package avaliacao;

import java.util.Scanner;

public class Leitora {
	private static Scanner s;

	static {
		System.out.println("Entrou aqui");
		s = new Scanner(System.in);
	}

	public static int lerInt(String msg) {
		System.out.println(msg);
		return Integer.parseInt(s.nextLine());

	}

	public static String ler(String msg) {
		System.out.println(msg);
		return s.nextLine();
	}

	public static double lerDouble(String msg) {
		System.out.println(msg);
		return Double.parseDouble(s.nextLine());
	}

	public static void println(String st) {
		System.out.println(st);
	}

	public static void println(int st) {
		System.out.println(st);
	}

	public static void println(double st) {
		System.out.println(st);
	}

	public static void print(String st) {
		System.out.print(st);
	}

	public static void print(int st) {
		System.out.print(st);
	}

	public static void print(double st) {
		System.out.print(st);
	}
}
