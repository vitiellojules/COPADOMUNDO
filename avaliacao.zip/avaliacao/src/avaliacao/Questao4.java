package avaliacao;

import static avaliacao.Leitora.*;

public class Questao4 {
	public static void main(String[] args) {
		int n = lerInt("Qual valor de linhas e colunas?");
		int[][] m = new int[n][n];
		for (int i = 0; i < m.length; i++) {
			int numero = lerInt("Número " + (i + 1));
			for (int j = 0; j < m.length; j++) {
				m[i][j] = numero;
			}
		}
		String totalCol="";
		String listra="";
		for (int i = 0; i < m.length; i++) {
			int totalLinha = 0;
			int totalColuna = 0;
			for (int j = 0; j < m.length; j++) {
				totalLinha += m[i][j];
				totalColuna+=m[j][i];
				print(m[i][j] + " ");
			}
			print("- " + totalLinha);
			println("");
			totalCol+=totalColuna+" ";
			listra+="- ";
		}
		println(listra);
		println(totalCol);

		/*for (int i = 0; i < m.length; i++) {
			int totalColuna = 0;
			for (int j = 0; j < m.length; j++) {
				totalColuna+=m[j][i];
			}
			
		}*/

	}
}
