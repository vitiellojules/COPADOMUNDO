package avaliacao;

import static avaliacao.Leitora.*;

public class Questao3 {
	public static void main(String[] args) {
		int n = lerInt("Quantidade de alunos:");
		String[] nomes = new String[n];
		double[] notas = new double[n];
		double soma = 0;
		
		for (int i = 0; i < notas.length; i++) {
			String nome = ler("Aluno " + (i + 1));
			double nota = lerDouble("Nota de " + nome);
			soma += nota;
			nomes[i] = nome;
			notas[i] = nota;
		}
		double media = soma/n;
		println("Nota media da turma: " + media);
		println("Alunos com media maior que "+media);
		
		for (int i = 0; i < notas.length; i++) {
			if (notas[i] >= media) {
				println(nomes[i] + " - " +notas[i]);
			}
		}
	}
}
