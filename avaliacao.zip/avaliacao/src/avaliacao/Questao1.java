package avaliacao;

import static avaliacao.Leitora.*;

import java.util.Iterator;

public class Questao1 {
	public static void main(String[] args) {
		int n = lerInt("Entre com a quantidade de números para ler:");
		int verificador = lerInt("Qual o número de verificação?");
		int[] num = new int[n];
		int cont = 0;
		for (int i = 0; i < num.length; i++) {
			num[i] = lerInt("Número " + (i + 1));
			if (num[i] > verificador) {
				cont++;
			}
		}
		print(cont + " números maiores que " + verificador);
	}
}
