package avaliacao;

import static avaliacao.Leitora.*;

public class Questao5 {
	public static void main(String[] args) {
		int linha = lerInt("Qual quantidade de linhas");
		int coluna = lerInt("Qual quantidade de colunas");
		int[][] m = new int[linha][coluna];
		int[][] res = new int[linha][coluna];
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				m[i][j] = lerInt("Numero " + (i + 1) + "," + (j + 1));
			}
		}
		println("Matriz");

		for (int i = 0; i < linha; i++) {
			for (int j = 0; j < coluna; j++) {
				print(m[i][j] + " ");

				res[i][j] = m[i][j];

				if ((i + 1) < linha) {
					res[i][j] += m[i + 1][j];
				}
				if ((j + 1) < coluna) {
					res[i][j] += m[i][j+1];
				}
			}
			println("");
		}

		println("Resultado final");

		for (int i = 0; i < linha; i++) {
			for (int j = 0; j < coluna; j++) {
				print(res[i][j] + " ");
			}
			println("");
		}
	}
}
