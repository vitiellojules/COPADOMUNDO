package avaliacao;

import static avaliacao.Leitora.*;

public class Questao2 {
	public static void main(String[] args) {
		int n = lerInt("Entre com a quantidade de numeros para ler:");
		int[] num = new int[n];

		for (int i = 0; i < num.length; i++) {
			num[i] = lerInt("Numero " + (i + 1));
		}

		print("Numeros lidos: ");
		for (int i = 0; i < num.length; i++) {
			print(num[i] + " ");
		}
		print("\n");

		print("Numeros pares invertidos: ");
		for (int i = num.length - 1; i >= 0; i--) {
			if (num[i] % 2 == 0) {
				print(num[i] + " ");
			}
		}

	}
}
